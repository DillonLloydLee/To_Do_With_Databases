-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 24, 2015 at 11:18 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do_test`
--
CREATE DATABASE IF NOT EXISTS `to_do_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `to_do_test`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `name` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=659 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories_tasks`
--

CREATE TABLE IF NOT EXISTS `categories_tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_tasks`
--

INSERT INTO `categories_tasks` (`id`, `category_id`, `task_id`) VALUES
(1, 136, 99),
(2, 136, 100),
(3, 154, 112),
(4, 154, 113),
(5, 172, 125),
(6, 172, 126),
(7, 190, 138),
(8, 190, 139),
(9, 201, 201),
(10, 208, 151),
(11, 208, 152),
(12, 219, 219),
(13, 226, 164),
(14, 226, 165),
(15, 237, 237),
(16, 244, 177),
(17, 244, 178),
(18, 255, 255),
(19, 262, 190),
(20, 262, 191),
(21, 273, 192),
(22, 280, 204),
(23, 280, 205),
(24, 291, 206),
(25, 299, 219),
(26, 299, 220),
(27, 310, 221),
(28, 317, 233),
(29, 318, 234),
(30, 319, 234),
(31, 320, 235),
(32, 320, 236),
(33, 331, 237),
(34, 338, 249),
(35, 339, 250),
(36, 340, 250),
(37, 341, 251),
(38, 341, 252),
(39, 352, 253),
(40, 359, 265),
(41, 360, 266),
(42, 361, 266),
(43, 362, 267),
(44, 362, 268),
(45, 373, 269),
(46, 380, 281),
(47, 381, 282),
(48, 382, 282),
(49, 383, 283),
(50, 383, 284),
(51, 394, 285),
(52, 402, 297),
(53, 403, 298),
(54, 404, 298),
(55, 405, 299),
(56, 406, 300),
(57, 406, 301),
(58, 417, 302),
(59, 418, 303),
(60, 425, 315),
(61, 426, 316),
(62, 427, 316),
(63, 428, 317),
(64, 429, 318),
(65, 429, 319),
(66, 440, 320),
(67, 441, 321),
(68, 448, 333),
(69, 449, 334),
(70, 450, 334),
(71, 451, 335),
(72, 452, 336),
(73, 452, 337),
(74, 463, 338),
(76, 471, 351),
(77, 472, 352),
(78, 473, 352),
(80, 521, 354),
(81, 521, 355),
(82, 532, 356),
(84, 540, 369),
(85, 541, 370),
(86, 542, 370),
(88, 544, 372),
(89, 544, 373),
(90, 555, 374),
(92, 563, 387),
(93, 564, 388),
(94, 565, 388),
(96, 567, 391),
(97, 567, 392),
(98, 578, 393),
(100, 586, 406),
(101, 587, 407),
(102, 588, 407),
(104, 590, 410),
(105, 590, 411),
(106, 601, 412),
(108, 609, 425),
(109, 610, 426),
(110, 611, 426),
(112, 613, 429),
(113, 613, 430),
(114, 624, 431),
(116, 632, 444),
(117, 633, 445),
(118, 634, 445),
(120, 636, 448),
(121, 636, 449),
(122, 647, 450),
(124, 655, 463),
(125, 656, 464),
(126, 657, 464);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `description` varchar(255) NOT NULL,
  `id` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `complete` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=467 DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=659;
--
-- AUTO_INCREMENT for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=467;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
